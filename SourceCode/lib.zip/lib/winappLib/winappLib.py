
import time

class WinappLib(object):
    """
    This driver does action to user interface of application linked.
    """
    def __init__(self):
        """

        """

        pass

    def wait_until_object_visible(self,sym_Name,sec=10):
        """
        :param sym_Name:
        :return:
        """
        start_time = time.time()
        while time.time() < start_time+sec:
            try:
                return waitForObjectExists(sym_Name)
            except:
                snooze(1)
        test.fail("The given object '{}' is not visible ...".format(sym_Name))
        return None


    def checkbox_is_checked(self,sym_Name):
        """
        check specfied checkbox is checked.
        :param sym_Name:
        :return:
        """
        tbl = self.wait_until_object_visible(sym_Name)
        if tbl:
            obj = tbl.nativeObject
            return test.compare(True,obj.IsEnabled)

    def compare_text(self,sym_name,text):
        """
        Get text from object and compares with text given by user.
        :param sym_name:
        :param text:
        :return:
        """
        tbl = self.wait_until_object_visible(sym_name)
        if tbl:
            t=tbl.text
            if isinstance(t,str):
                return test.compare(t,text)
        test.fail("Error in parsing test from symbolic name '{}".format(sym_name))
        return None

    def set_text(self,sym_name,txt):
        """

        :param sym_name:
        :return:
        """
        tbl = self.wait_until_object_visible(sym_name)
        if tbl:
                type(tbl,txt)
                return True
        test.fail("Error in parsing test from symbolic name '{}".format(sym_name))
        return None

    def click_and_select_list_Box(self,sym_name,value):
        """

        :param sym_name:
        :param value:
        :return:
        """
        tbl = self.wait_until_object_visible(sym_name)
        if tbl:
            mouseClick(tbl, MouseButton.PrimaryButton)
            type(tbl,txt)
            return True
        test.fail("Error in parsing test from symbolic name '{}".format(sym_name))
        return None





