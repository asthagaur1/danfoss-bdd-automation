def remove_spaces_with_underscore(input_str):
    """
    Remove spaces with underscore in input string.
    :param input_str: input string
    :return:
    string
    """
    return input_strreplace(" ", "_")


def make_string_small_letters(input_str):
    """

    :param input_str:
    :return:
    """
    return input_str.lower()
