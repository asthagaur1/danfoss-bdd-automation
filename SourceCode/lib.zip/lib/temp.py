

args = ['a','b','c','d','e']

s = str(args)

s.replace("")