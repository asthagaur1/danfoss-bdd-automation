# -*- coding: utf-8 -*-

import winappLib


class KoolprogApi(object):
    """
    """
    pass


class MainWindow(object):

    def __init__(self):
        """
        """
        pass

    def check_koolprog_version(self, version_string):
        """
        validate koolprog version
        """
        self.test = None

    def check_parameter_label_text(self, expected_string):
        """
        """
        pass

    def check_copy_to_controller_label_text(self, expected_string):
        """
        """
        pass

    def check_on_line_service_label_text(self, expected_string):
        """
        """
        pass

    def check_wesite_label_text(self, expected_string):
        """
        """
        pass

    def click_set_parameter_button(self):
        """
        """
        pass

    def click_copy_controller_button(self):
        """
        """
        pass

    def click_on_line_service_button(self):
        """
        """
        pass


class SetparamWindow(object):
    """
    """

    def __init__(self, *args, **kwargs):
        object.__init__(self, *args, **kwargs)
        pass

    def check_open_recent_label(self, expected_text):
        """
        """
        pass

    def check_setting_files_label(self):
        """
        """
        pass

    def click_new_button(self):
        """
        """
        pass

    def click_import_settings_button(self):
        """
        """
        pass

    def click_open_button(self):
        """
        """
        pass

    def check_controller_model_label(self):
        """
        """
        pass

    def click_import_controller_model(self):
        """
        """
        pass

    def click_close_button(self):
        """
        """
        pass




